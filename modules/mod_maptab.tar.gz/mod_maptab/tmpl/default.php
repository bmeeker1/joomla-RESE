<?php // no direct access
defined( '_JEXEC' ) or die( 'Restricted access' ); ?>
<div class="lfttop">
	<ul class="toplist reset">
		<li class="active"><a href="#" class="real">Property</a></li>
		<li><a href="#" class="offc">ERA Offices</a></li>
	</ul>
	<div class="imgdiv"><img src="templates/yoo_symphony/images/mapimg.png" alt="image" /></div>
</div>
