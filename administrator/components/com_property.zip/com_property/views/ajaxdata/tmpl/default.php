<?php
		if(!empty($this->district_list)){
		 echo json_encode($this->district_list);
		}
		if(!empty($this->city_list)){
		 echo json_encode($this->city_list);
		}
?>