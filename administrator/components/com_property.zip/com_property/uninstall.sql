DROP TABLE IF EXISTS `#__property`;
DROP TABLE IF EXISTS `#__property_detail`;
DROP TABLE IF EXISTS `#__property_image`;
DROP TABLE IF EXISTS `#__property_type`;
DROP TABLE IF EXISTS `#__property_city`;
DROP TABLE IF EXISTS `#__property_district`;
DROP TABLE IF EXISTS `#__property_province`;
